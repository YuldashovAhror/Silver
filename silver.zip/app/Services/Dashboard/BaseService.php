<?php

namespace App\Services\Dashboard;

use App\Traits\FileTrait;

class BaseService
{
    use FileTrait;
}
