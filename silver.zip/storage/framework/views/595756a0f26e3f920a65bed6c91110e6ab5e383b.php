<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <title>Dashboard | Focus Ads</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo $__env->make('components.dashboard.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<div id="layout-wrapper">
    <?php echo $__env->make('components.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('components.dashboard.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main-content">
        <div class="page-content">
            <div class="container-fluid">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        <?php echo $__env->make('components.dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<?php echo $__env->make('components.dashboard.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html><?php /**PATH D:\wamp64\www\FocusAds\resources\views/layouts/dashboard/main.blade.php ENDPATH**/ ?>