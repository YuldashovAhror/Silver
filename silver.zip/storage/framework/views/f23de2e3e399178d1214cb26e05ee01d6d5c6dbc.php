

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Видео</h4>
                    <form class="needs-validation" action="<?php echo e(route('baner.update', $baner)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('put')); ?>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-3">
                                   <div class="col-md-12 text-center">
                                       <video width="320" height="240" controls>
                                           <source src="<?php echo e($baner->baner ?? null); ?>" type="video/mp4">
                                       </video>
                                   </div>
                                    <input type="file" class="form-control" id="validationCustom01" required="" name="baner">
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-primary" type="submit">Сохранить</button>
                    </form>
                </div>
            </div>
            <!-- end card -->
        </div> <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\FocusAds\resources\views/dashboard/baner/create.blade.php ENDPATH**/ ?>