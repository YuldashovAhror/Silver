
<?php $__env->startSection('content'); ?>
<div class="col-sm-6" style="padding-top: 2rem; padding-bottom: 1.5rem">
    <h3>Заказать</h3>
</div>
<div class="row">
    <div class="col-sm-12">
        <div class="card-header">
            <h5>Список</h5>
        </div>
        <div class="table-responsive">
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Название</th>
                    <th scope="col">Телефон</th>
                    <th scope="col">Выберите область</th>
                    <th scope="col">Бренд</th>
                    <th scope="col">Продукт название</th>
                    <th scope="col">Action</th>
                </tr>
                </thead>
                <?php
                $num = 1;
                ?>
                
                <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($num++); ?></th>
                        <td ><?php echo e($order->name); ?></td>
                        <td><?php echo e($order->phone); ?></td>
                        <td><?php echo e($order->location->name_ru); ?></td>
                        <td><?php echo e($order->brend->name); ?></td>
                        <td><?php echo e($order->product->name_ru); ?></td>
                        <td>
                            <button class="btn btn-xs btn-danger" type="button" data-bs-toggle="modal" data-bs-target="#exampleModalCenter<?php echo e($order->id); ?>"><i class="bx bx-trash"></i></button>
                            <div class="modal fade" id="exampleModalCenter<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="exampleModalCenter" style="display: none;" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Удалить?</h5>
                                        </div>
                                        <div class="modal-footer">
                                            <form action="<?php echo e(route('korzina.destroy', $order->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo e(method_field('delete')); ?>

                                                <button class="btn btn-primary" type="submit" data-bs-original-title="" title="">Да</button>
                                            </form>
                                            <button class="btn btn-secondary" type="button" data-bs-dismiss="modal" data-bs-original-title="" title="">Нет</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\silver\resources\views/dashboard/orders/index.blade.php ENDPATH**/ ?>