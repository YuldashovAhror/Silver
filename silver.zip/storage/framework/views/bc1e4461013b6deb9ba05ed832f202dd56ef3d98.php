<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © Novas.
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\wamp64\www\silver\resources\views/components/dashboard/footer.blade.php ENDPATH**/ ?>