

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Услуги</h4>
                    <form class="needs-validation" action="<?php echo e(route('services.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label class="form-label" for="validationCustom01">Фото</label>
                                    <input type="file" class="form-control" id="validationCustom01" required="" name="photo">
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label" for="validationCustom01">Название RU</label>
                                    <input type="text" class="form-control" id="validationCustom01" required="" name="name_ru">
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label" for="validationCustom02">Название UZ</label>
                                    <input type="text" class="form-control" id="validationCustom02" required="" name="name_uz">
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label" for="validationCustom02">Название EN</label>
                                    <input type="text" class="form-control" id="validationCustom02" required="" name="name_en">
                                    <div class="valid-feedback">
                                        Looks good!
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-primary" type="submit">Сохранить</button>
                    </form>
                </div>
            </div>
            <!-- end card -->
        </div> <!-- end col -->
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Все</h4>
                    <div class="table-responsive">
                        <table class="table table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Фото</th>
                                    <th>Название RU</th>
                                    <th>Название UZ</th>
                                    <th>Название EN</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php ($k=1); ?>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($k); ?></th>
                                    <td><img src="<?php echo e($service->photo); ?>" alt="" style="height: 100px; width: 100px"></td>
                                    <td><?php echo e($service->name_ru); ?></td>
                                    <td><?php echo e($service->name_uz); ?></td>
                                    <td><?php echo e($service->name_en); ?></td>
                                    <td>
                                        <button class="btn btn-success" type="button" data-bs-toggle="modal" data-bs-target=".bs-example-modal-center<?php echo e($service->id); ?>Edit">
                                            <i class="uil uil-pen"></i>
                                        </button>

                                        <button class="btn btn-danger" type="button" data-bs-toggle="modal" data-bs-target=".bs-example-modal-center<?php echo e($service->id); ?>Delete">
                                            <i class="uil uil-trash"></i>
                                        </button>
                                    </td>
                                    <div class="modal fade bs-example-modal-center<?php echo e($service->id); ?>Edit" tabindex="-1" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered" style="max-width: 60vw">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Изменить</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form class="needs-validation" action="<?php echo e(route('services.update', $service)); ?>" method="post" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo e(method_field('put')); ?>

                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="mb-3">
                                                                    <label class="form-label" for="validationCustom01">Фото</label>
                                                                    <div class="col-md-12 text-center">
                                                                        <img src="<?php echo e($service->photo); ?>" alt="" style="height: 200px; width: 200px">
                                                                    </div>
                                                                    <input type="file" class="form-control mt-2" id="validationCustom01" required="" name="photo">
                                                                    <div class="valid-feedback">
                                                                        Looks good!
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <div class="mb-3">
                                                                    <label class="form-label" for="validationCustom01">Название RU</label>
                                                                    <input type="text" class="form-control" id="validationCustom01" required="" name="name_ru" value="<?php echo e($service->name_ru); ?>">
                                                                    <div class="valid-feedback">
                                                                        Looks good!
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="mb-3">
                                                                    <label class="form-label" for="validationCustom02">Название UZ</label>
                                                                    <input type="text" class="form-control" id="validationCustom02" required="" name="name_uz" value="<?php echo e($service->name_uz); ?>">
                                                                    <div class="valid-feedback">
                                                                        Looks good!
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="mb-3">
                                                                    <label class="form-label" for="validationCustom02">Название EN</label>
                                                                    <input type="text" class="form-control" id="validationCustom02" required="" name="name_en" value="<?php echo e($service->name_en); ?>">
                                                                    <div class="valid-feedback">
                                                                        Looks good!
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <button class="btn btn-primary" type="submit">Сохранить</button>
                                                    </form>
                                                </div>
                                            </div><!-- /.modal-content -->
                                        </div><!-- /.modal-dialog -->
                                    </div>
                                    <div class="modal fade bs-example-modal-center<?php echo e($service->id); ?>Delete" tabindex="-1" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Удалить?</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('services.destroy', $service)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo e(method_field('delete')); ?>

                                                        <div class="row">
                                                            <div class="col-md-6 text-center">
                                                                <button class="btn btn-success" type="submit">да</button>
                                                            </div>
                                                            <div class="col-md-6 text-center">
                                                                <button class="btn btn-danger">нет</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div><!-- /.modal-content -->
                                        </div><!-- /.modal-dialog -->
                                    </div>
                                    <?php ($k++); ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\FocusAds\resources\views/dashboard/service/create.blade.php ENDPATH**/ ?>