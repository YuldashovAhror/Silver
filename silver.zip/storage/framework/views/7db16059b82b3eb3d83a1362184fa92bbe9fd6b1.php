<a href="index.html" class="mb-5 d-block auth-logo">
    <img src="/assets/images/logo-dark.png" alt="" height="22" class="logo logo-dark">
    <img src="/assets/images/logo-light.png" alt="" height="22" class="logo logo-light">
</a><?php /**PATH D:\wamp64\www\Pattern\resources\views/components/auth/logo.blade.php ENDPATH**/ ?>