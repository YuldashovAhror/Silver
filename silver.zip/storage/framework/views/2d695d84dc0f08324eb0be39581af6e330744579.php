<footer class="footer">
</footer>
<?php /**PATH C:\wamp64\www\parkent\resources\views/components/front/footer.blade.php ENDPATH**/ ?>