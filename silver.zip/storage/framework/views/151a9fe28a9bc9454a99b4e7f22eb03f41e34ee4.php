<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="/css/swiper.min.css">
    <link rel="stylesheet" href="/css/fancybox.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="preloader" style="display: none">
        <div class="preloader__logo">

        </div>
    </div>
    <?php echo $__env->make('components.front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="/js/swiper.min.js"></script>
    <script src="/js/fancybox.umd.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.front.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\parkent\resources\views/welcome.blade.php ENDPATH**/ ?>