<header class="header">
</header>
<?php /**PATH C:\wamp64\www\parkent\resources\views/components/front/header.blade.php ENDPATH**/ ?>