


<div class="popup__back"></div>


<div class="popup">
    <span class="close popup__close">
        <svg width="31" height="31" viewBox="0 0 31 31" fill="none" xmlns="http://www.w3.org/2000/svg">
<circle cx="15.5" cy="15.5" r="15.5" transform="rotate(90 15.5 15.5)" fill="white"/>
<path d="M12.2192 18.3569L18.3569 12.2192" stroke="#323232" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M18.3569 18.357L12.2192 12.2193" stroke="#323232" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
    </span>
    
    <div class="popup__container" style="display: block">
    </div>
    
    <div class="popup__success" style="display: none">
    </div>
</div>
<?php /**PATH C:\wamp64\www\parkent\resources\views/components/front/popup.blade.php ENDPATH**/ ?>