<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="products__item">
    <div class="products__item-pic">
        <img src="<?php echo e($product->photos[0]); ?>" alt="">
    </div>
    <!-- /.products__item-pic -->
    <div class="products__item-content">
        <h3 class="products__name"><?php echo e($product['name_'.$lang]); ?></h3>
        <!-- /.products__name -->
        <div class="products__item-bottom">
            <h4 class="price general-SM">
                <?php echo e($product->price); ?>

                <span class="general-M"><?php echo e(__('asd.Cум')); ?></span>
            </h4>
            <!-- /.price -->
            <a href="<?php echo e(route('product.shows', $product->id)); ?>" class="more general-SM"><?php echo e(__('asd.Заказать')); ?></a>
            <!-- /. -->
        </div>
        <!-- /.products__item-bottom -->
    </div>
    <!-- /.product__item-content -->
</div>
<!-- /.products__item -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\wamp64\www\silver\resources\views/load.blade.php ENDPATH**/ ?>