
<?php $__env->startSection('styles'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('word')->html();
} elseif ($_instance->childHasBeenRendered('n94N3hu')) {
    $componentId = $_instance->getRenderedChildComponentId('n94N3hu');
    $componentTag = $_instance->getRenderedChildComponentTagName('n94N3hu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('n94N3hu');
} else {
    $response = \Livewire\Livewire::mount('word');
    $html = $response->html();
    $_instance->logRenderedChild('n94N3hu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\silver\resources\views/dashboard/word.blade.php ENDPATH**/ ?>