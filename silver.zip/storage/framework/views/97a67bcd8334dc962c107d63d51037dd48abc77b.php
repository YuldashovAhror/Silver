<div class="vertical-menu">

    <!-- LOGO -->
    <div class="navbar-brand-box">
        <a href="/" class="logo logo-dark">
            <span class="logo-sm">
                <img src="/img/logo.svg" alt="" height="22" style="height: 40px; width: 40px">
            </span>
            <span class="logo-lg">
                <img src="/img/logo.svg" alt="" height="20" style="height: 100px; width: 100px">
            </span>
        </a>
    </div>

    <button type="button" class="btn btn-sm px-3 font-size-16 header-item waves-effect vertical-menu-btn">
        <i class="fa fa-fw fa-bars"></i>
    </button>

    <div data-simplebar class="sidebar-menu-scroll">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled mt-4" id="side-menu">
                <li class="menu-title">Menu</li>
                <li>
                    <a href="/dashboard">
                        <i class="uil-home-alt"></i>
                        <span>Главная</span>
                    </a>
                </li>
                <li>
                    <a href="/asd">
                        <i class="uil-home-alt"></i>
                        <span>Видео банер</span>
                    </a>
                </li>
                <li>
                    <a href="/qwe">
                        <i class="uil-home-alt"></i>
                        <span>Услуги</span>
                    </a>
                </li>
                <li>
                    <a href="/zxc">
                        <i class="uil-home-alt"></i>
                        <span>Реализованные проекты</span>
                    </a>
                </li>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div><?php /**PATH D:\wamp64\www\Pattern\resources\views/components/dashboard/sidebar.blade.php ENDPATH**/ ?>