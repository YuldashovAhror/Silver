<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/intlTelInput.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/main.css">
    <title>Focus Ads</title>
</head>
<body>

<!-- PRELOADER -->

<div class="preloader">
    <div class="preloader__img">
        <img src="img/preloader.svg" alt="Focus Ads">
        <span class="ripple ripple-1"></span>
        <span class="ripple ripple-2"></span>
    </div>
</div>


<!-- ZOOM-IMAGE -->

<div class="zoom-image">
    <svg class="zoom-image__close" width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M11.5237 10.6259L19.8274 18.9295L18.9125 19.8445L10.6088 11.5408L1.92532 20.2243L0.975834 19.2748L9.6593 10.5914L1.68363 2.61569L2.59859 1.70073L10.5743 9.67639L19.275 0.975667L20.2245 1.92515L11.5237 10.6259Z" fill="black"/>
    </svg>
    <div class="zoom-image-carousel owl-carousel">

    </div>
    <div class="zoom-image-arrow">
			<span class="arrow-left">
				<img src="img/arrow-left-white.svg" alt="ico">
			</span>
        <span class="arrow-right">
				<img src="img/arrow-right-white.svg" alt="ico">
			</span>
    </div>
</div>


<!-- MOBILE MENU -->

<div class="mobile-menu">
    <div class="mobile-menu__wrap">
        <ul class="mobile-menu__list">
            <li>
                <a href="#about">
                    О компании
                </a>
            </li>
            <li>
                <a href="#services">
                    Услуги
                </a>
            </li>
            <li>
                <a href="#projects">
                    Портфолио
                </a>
            </li>
            <li>
                <a href="#footer">
                    Контакты
                </a>
            </li>
        </ul>
        <ul class="footer-info__social">
            <li>
                <a href="#" target="_blank">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M20.9487 5.39287L18.2324 18.3764C18.0275 19.2928 17.493 19.5208 16.7336 19.0891L12.5948 15.998L10.5978 17.9447C10.3768 18.1687 10.1919 18.3561 9.76602 18.3561L10.0634 14.0839L17.7341 7.05857C18.0677 6.7572 17.6618 6.59022 17.2158 6.89159L7.7328 12.9435L3.65029 11.6484C2.76227 11.3674 2.7462 10.7484 3.83513 10.3167L19.8035 4.08148C20.5429 3.80047 21.1898 4.24845 20.9487 5.39287Z" fill="#fff"/>
                    </svg>
                </a>
            </li>
            <li>
                <a href="#" target="_blank">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M11.9978 9.3321C10.5289 9.3321 9.3301 10.5309 9.3301 11.9999C9.3301 13.4688 10.5289 14.6676 11.9978 14.6676C13.4668 14.6676 14.6656 13.4688 14.6656 11.9999C14.6656 10.5309 13.4668 9.3321 11.9978 9.3321ZM19.9991 11.9999C19.9991 10.8951 20.0091 9.80041 19.9471 8.69768C19.885 7.41684 19.5928 6.28009 18.6562 5.34348C17.7176 4.40486 16.5829 4.11467 15.302 4.05263C14.1973 3.99059 13.1026 4.0006 11.9999 4.0006C10.8951 4.0006 9.80041 3.99059 8.69768 4.05263C7.41684 4.11467 6.28009 4.40686 5.34348 5.34348C4.40486 6.28209 4.11467 7.41684 4.05263 8.69768C3.99059 9.80241 4.0006 10.8971 4.0006 11.9999C4.0006 13.1026 3.99059 14.1993 4.05263 15.302C4.11467 16.5829 4.40686 17.7196 5.34348 18.6562C6.28209 19.5948 7.41684 19.885 8.69768 19.9471C9.80241 20.0091 10.8971 19.9991 11.9999 19.9991C13.1046 19.9991 14.1993 20.0091 15.302 19.9471C16.5829 19.885 17.7196 19.5928 18.6562 18.6562C19.5948 17.7176 19.885 16.5829 19.9471 15.302C20.0111 14.1993 19.9991 13.1046 19.9991 11.9999ZM11.9978 16.1045C9.72636 16.1045 7.89315 14.2713 7.89315 11.9999C7.89315 9.72836 9.72636 7.89515 11.9978 7.89515C14.2693 7.89515 16.1025 9.72836 16.1025 11.9999C16.1025 14.2713 14.2693 16.1045 11.9978 16.1045ZM16.2707 8.68567C15.7403 8.68567 15.312 8.25739 15.312 7.72704C15.312 7.1967 15.7403 6.76841 16.2707 6.76841C16.801 6.76841 17.2293 7.1967 17.2293 7.72704C17.2294 7.85298 17.2048 7.9777 17.1566 8.09408C17.1085 8.21046 17.0379 8.3162 16.9489 8.40525C16.8598 8.4943 16.7541 8.5649 16.6377 8.61302C16.5213 8.66114 16.3966 8.68583 16.2707 8.68567Z" fill="white"/>
                    </svg>
                </a>
            </li>
            <li>
                <a href="#" target="_blank">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13.392 20V12.7135H15.8501L16.2155 9.86063H13.392V8.04345C13.392 7.22021 13.6213 6.65657 14.8028 6.65657H16.3V4.11306C15.5715 4.03499 14.8393 3.9973 14.1067 4.00015C11.934 4.00015 10.4422 5.32658 10.4422 7.76163V9.85529H8V12.7082H10.4475V20H13.392Z" fill="white"/>
                    </svg>
                </a>
            </li>
        </ul>
    </div>
</div>

<!-- HEADER -->

<header class="header">
    <div class="container">
        <nav class="header-nav">
            <div class="header__logo">
                <a href="#">
                    <img src="img/logo.svg" alt="Focus Ads" title="Focus Ads">
                </a>
            </div>
            <ul class="header-menu">
                <li>
                    <a href="#about">
                        О компании
                    </a>
                </li>
                <li>
                    <a href="#services">
                        Услуги
                    </a>
                </li>
                <li>
                    <a href="#projects">
                        Портфолио
                    </a>
                </li>
                <li>
                    <a href="#footer">
                        Контакты
                    </a>
                </li>
            </ul>
        </nav>
        <div class="header-wrap">
            <a href="tel:+998999107770" class="header__tel">
                <div>
                    <svg width="36" height="36" viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="17.7945" cy="17.7946" r="17.3722" fill="white"/>
                        <circle cx="17.7945" cy="17.7946" r="16.8722" stroke="white" stroke-opacity="0.5"/>
                        <path d="M21.8678 24.5946C20.6638 24.5946 19.3821 24.2528 18.0596 23.5803C16.8405 22.9593 15.6368 22.0702 14.577 21.0095C13.517 19.9488 12.6299 18.7434 12.0098 17.5237C11.3377 16.2 10.9963 14.9189 10.9963 13.7146C10.9963 12.9342 11.7241 12.1798 12.0362 11.8924C12.4858 11.4784 13.1931 10.9946 13.7069 10.9946C13.9629 10.9946 14.262 11.1619 14.6499 11.521C14.9394 11.789 15.2647 12.1518 15.5901 12.5707C15.7866 12.8238 16.7667 14.1155 16.7667 14.7347C16.7667 15.2424 16.1922 15.5962 15.5847 15.9698C15.3491 16.1137 15.1067 16.263 14.9312 16.4037C14.7436 16.5547 14.7094 16.6341 14.7042 16.6516C15.3497 18.2605 17.3228 20.2335 18.9302 20.8777C18.9448 20.8731 19.0245 20.8418 19.1774 20.6509C19.3181 20.4758 19.4681 20.2321 19.6117 19.9975C19.9861 19.39 20.3394 18.815 20.8468 18.815C21.4665 18.815 22.758 19.7951 23.0104 19.9916C23.4301 20.3171 23.7925 20.6428 24.061 20.9318C24.4196 21.3197 24.5868 21.6193 24.5868 21.8748C24.5868 22.3896 24.1034 23.0987 23.6904 23.5506C23.4023 23.8646 22.6477 24.5949 21.8669 24.5949L21.8678 24.5946Z" fill="#025DFF"/>
                    </svg>
                </div>
                <span>+998 99 910 77 70</span>
            </a>
            <div class="header-mobile">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </div>
</header>

<!-- MAIN -->

<section class="main">
    <div class="main__video">
        <video src="<?php echo e($baner->baner); ?>" pip="false" autoplay="autoplay" loop="loop" muted="muted" playsinline="" webkit-playsinline=""></video>
    </div>
    <div class="container">
        <div class="main-content">
            <h1 class="main__title">
                <div class="main__title-wrap">
                    <div>FOCUS </div>
                </div>
                <div class="main__title-wrap">
                    <div>ADVERTISING</div>
                </div>
            </h1>
            <div class="main-text">
                <div class="main-text__yellow main__focus">
                    Сфокусируйтесь
                </div>
                <div class="main-text__blur main__result">
                    на результат
                </div>
            </div>
            <a href="#form" class="main__btn">
                Связаться с нами
            </a>
        </div>
    </div>
    <ul class="main-social">
        <li>
            <a href="#" target="_blank">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20.9487 5.39287L18.2324 18.3764C18.0275 19.2928 17.493 19.5208 16.7336 19.0891L12.5948 15.998L10.5978 17.9447C10.3768 18.1687 10.1919 18.3561 9.76602 18.3561L10.0634 14.0839L17.7341 7.05857C18.0677 6.7572 17.6618 6.59022 17.2158 6.89159L7.7328 12.9435L3.65029 11.6484C2.76227 11.3674 2.7462 10.7484 3.83513 10.3167L19.8035 4.08148C20.5429 3.80047 21.1898 4.24845 20.9487 5.39287Z" fill="#fff"/>
                </svg>
            </a>
        </li>
        <li>
            <a href="#" target="_blank">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M11.9978 9.3321C10.5289 9.3321 9.3301 10.5309 9.3301 11.9999C9.3301 13.4688 10.5289 14.6676 11.9978 14.6676C13.4668 14.6676 14.6656 13.4688 14.6656 11.9999C14.6656 10.5309 13.4668 9.3321 11.9978 9.3321ZM19.9991 11.9999C19.9991 10.8951 20.0091 9.80041 19.9471 8.69768C19.885 7.41684 19.5928 6.28009 18.6562 5.34348C17.7176 4.40486 16.5829 4.11467 15.302 4.05263C14.1973 3.99059 13.1026 4.0006 11.9999 4.0006C10.8951 4.0006 9.80041 3.99059 8.69768 4.05263C7.41684 4.11467 6.28009 4.40686 5.34348 5.34348C4.40486 6.28209 4.11467 7.41684 4.05263 8.69768C3.99059 9.80241 4.0006 10.8971 4.0006 11.9999C4.0006 13.1026 3.99059 14.1993 4.05263 15.302C4.11467 16.5829 4.40686 17.7196 5.34348 18.6562C6.28209 19.5948 7.41684 19.885 8.69768 19.9471C9.80241 20.0091 10.8971 19.9991 11.9999 19.9991C13.1046 19.9991 14.1993 20.0091 15.302 19.9471C16.5829 19.885 17.7196 19.5928 18.6562 18.6562C19.5948 17.7176 19.885 16.5829 19.9471 15.302C20.0111 14.1993 19.9991 13.1046 19.9991 11.9999ZM11.9978 16.1045C9.72636 16.1045 7.89315 14.2713 7.89315 11.9999C7.89315 9.72836 9.72636 7.89515 11.9978 7.89515C14.2693 7.89515 16.1025 9.72836 16.1025 11.9999C16.1025 14.2713 14.2693 16.1045 11.9978 16.1045ZM16.2707 8.68567C15.7403 8.68567 15.312 8.25739 15.312 7.72704C15.312 7.1967 15.7403 6.76841 16.2707 6.76841C16.801 6.76841 17.2293 7.1967 17.2293 7.72704C17.2294 7.85298 17.2048 7.9777 17.1566 8.09408C17.1085 8.21046 17.0379 8.3162 16.9489 8.40525C16.8598 8.4943 16.7541 8.5649 16.6377 8.61302C16.5213 8.66114 16.3966 8.68583 16.2707 8.68567Z" fill="white"/>
                </svg>
            </a>
        </li>
        <li>
            <a href="#" target="_blank">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M13.392 20V12.7135H15.8501L16.2155 9.86063H13.392V8.04345C13.392 7.22021 13.6213 6.65657 14.8028 6.65657H16.3V4.11306C15.5715 4.03499 14.8393 3.9973 14.1067 4.00015C11.934 4.00015 10.4422 5.32658 10.4422 7.76163V9.85529H8V12.7082H10.4475V20H13.392Z" fill="white"/>
                </svg>
            </a>
        </li>
    </ul>
</section>

<!-- PARTNERS -->

<section class="partners" id="about">
    <div class="container">
        <div class="partners-wrap">
            <div class="partners-content">
                <h2 class="partners__title wow fadeInLeft" data-wow-delay=".2s">
                    Ваш надежный парнёр на рынке производства рекламы
                </h2>
                <p class="partners__text wow fadeInLeft" data-wow-delay=".3s">
                    Современная система производительности, оборудования последнего поколения и профессионалы своего дела исполнят поставленные задачи в наилучшем качестве и в кратчайшие сроки.
                </p>
            </div>
            <div class="partners-numbers">
                <div class="partners-numbers__item">
                    <div class="partners-numbers__number">
                        <span>10</span>+
                    </div>
                    <div class="partners-numbers__text">
                        Лет <br> на рынке
                    </div>
                </div>
                <div class="partners-numbers__item">
                    <div class="partners-numbers__number">
                        <span>1000000</span>+
                    </div>
                    <div class="partners-numbers__text">
                        Напечатанных  <br> рекламных материалов
                    </div>
                </div>
                <div class="partners-numbers__item">
                    <div class="partners-numbers__number">
                        <span>1000</span>+
                    </div>
                    <div class="partners-numbers__text">
                        Успешных<br> проектов
                    </div>
                </div>
                <div class="partners-numbers__item">
                    <div class="partners-numbers__number">
                        <span>250</span>+
                    </div>
                    <div class="partners-numbers__text">
                        Довольных<br> клиентов
                    </div>
                </div>
            </div>
        </div>
        <div class="partners__img">
            <img src="img/partners.png" alt="partners">
        </div>
    </div>
</section>

<!-- ABOUT -->

<section class="about">
    <div class="container">
        <h2 class="about__title section-title">
            Наша миссия, видение и ценности
        </h2>
        <div class="about-wrap">
            <div class="about-item wow fadeInUp" data-wow-delay=".2s">
                <div class="about-item__ico">
                    <svg width="194" height="194" viewBox="0 0 194 194" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="97" cy="97" r="97" fill="white"/>
                        <path d="M43.9629 44.9626H148V149H43.9629V44.9626Z" fill="white" fill-opacity="0.01"/>
                        <path d="M90.3837 85.24C86.0033 87.3322 82.9771 91.8032 82.9771 96.9813C82.9771 104.164 88.7996 109.986 95.9818 109.986C101.16 109.986 105.631 106.96 107.723 102.58" stroke="#141DE0" stroke-width="6.49689" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M105.257 70.3668C102.352 69.3548 99.2312 68.8047 95.9817 68.8047C80.4201 68.8047 67.8049 81.4199 67.8049 96.9815C67.8049 112.543 80.4201 125.158 95.9817 125.158C111.543 125.158 124.158 112.543 124.158 96.9815C124.158 93.732 123.608 90.6109 122.596 87.7063" stroke="#141DE0" stroke-width="6.49689" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M116.719 58.9049C110.559 55.5431 103.493 53.6324 95.9815 53.6324C72.0406 53.6324 52.6326 73.0404 52.6326 96.9813C52.6326 120.922 72.0406 140.33 95.9815 140.33C119.922 140.33 139.33 120.922 139.33 96.9813C139.33 89.4696 137.42 82.4042 134.058 76.2443" stroke="#141DE0" stroke-width="6.49689" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M139.33 53.6326L95.9815 96.9815" stroke="#141DE0" stroke-width="6.49689" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </div>
                <div class="about-item__wrap">
                    <h3 class="about-item__name">
                        Миссия
                    </h3>
                    <div class="about-item__text">
                        Оказывать качественные, оперативные, гибкие решения с систематическими улучшениями
                    </div>
                </div>
            </div>
            <div class="about-item wow fadeInUp" data-wow-delay=".3s">
                <div class="about-item__ico">
                    <svg width="194" height="194" viewBox="0 0 194 194" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="97" cy="97" r="97" fill="white"/>
                        <path d="M66.3024 108.361L52 122.377V82.1398H66.3024M90.1398 99.5887L82.6548 93.2003L75.8373 99.4933V63.0699H90.1398M113.977 91.6747L99.6747 105.977V44H113.977M127.374 90.7689L118.745 82.1398H142.582V105.977L134.048 97.4433L99.6747 131.531L83.1316 117.133L65.1105 134.582H52L82.8455 104.356L99.6747 118.563" fill="#141DE0"/>
                    </svg>
                </div>
                <div class="about-item__wrap">
                    <h3 class="about-item__name">
                        Видение
                    </h3>
                    <div class="about-item__text">
                        Стабильная компания с лучшими талантами, двигающая границы индустрии и задающая темп
                    </div>
                </div>
            </div>
            <div class="about-item wow fadeInUp" data-wow-delay=".4s">
                <div class="about-item__ico">
                    <svg width="194" height="194" viewBox="0 0 194 194" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="97" cy="97" r="97" fill="white"/>
                        <path d="M97.1626 51C88.7038 51 81.8466 57.8573 81.8466 66.3162C81.8466 74.775 88.7038 81.6322 97.1626 81.6322C105.622 81.6322 112.479 74.775 112.479 66.3162C112.479 57.8573 105.622 51 97.1626 51V51Z" fill="#141DE0"/>
                        <path d="M131.659 58.6506C125.309 58.6506 120.16 63.7987 120.16 70.1492C120.16 76.4997 125.309 81.6478 131.659 81.6478C138.009 81.6478 143.157 76.4997 143.157 70.1492C143.157 63.7987 138.009 58.6506 131.659 58.6506Z" fill="#141DE0"/>
                        <path d="M62.6673 58.6506C56.3168 58.6506 51.1688 63.7987 51.1688 70.1492C51.1688 76.4997 56.3168 81.6478 62.6673 81.6478C69.0178 81.6478 74.1659 76.4997 74.1659 70.1492C74.1659 63.7987 69.0178 58.6506 62.6673 58.6506Z" fill="#141DE0"/>
                        <path d="M74.1659 96.9259C74.1925 92.715 77.6143 89.3097 81.8314 89.3097H112.494C116.728 89.3097 120.16 92.7418 120.16 96.9755V119.975C120.16 120.768 120.12 121.553 120.041 122.326C119.875 123.967 119.535 125.557 119.042 127.078C116.05 136.303 107.385 142.972 97.1628 142.972C86.8433 142.972 78.1113 136.175 75.1996 126.813C74.5277 124.653 74.1657 122.357 74.1657 119.975V96.9754C74.1657 96.9589 74.1658 96.9424 74.1659 96.9259V96.9259Z" fill="#141DE0"/>
                        <path d="M66.5001 96.9754C66.5001 94.1829 67.2466 91.5648 68.5511 89.3097H51.1686C46.935 89.3097 43.5029 92.7418 43.5029 96.9754V116.142C43.5029 126.726 52.0831 135.306 62.6672 135.306C65.2055 135.306 67.6285 134.813 69.8456 133.917C67.7066 129.734 66.5001 124.995 66.5001 119.975V96.9754Z" fill="#141DE0"/>
                        <path d="M127.825 96.9755V119.975C127.825 124.995 126.618 129.734 124.479 133.917C126.696 134.813 129.119 135.306 131.658 135.306C142.242 135.306 150.822 126.726 150.822 116.142V96.9754C150.822 92.7418 147.39 89.3097 143.156 89.3097H125.773C127.078 91.5648 127.825 94.1829 127.825 96.9755V96.9755Z" fill="#141DE0"/>
                    </svg>
                </div>
                <div class="about-item__wrap">
                    <h3 class="about-item__name">
                        Ценности
                    </h3>
                    <div class="about-item__text">
                        <p>Голод к саморазвитию</p>
                        <p>Качественная оперативность</p>
                        <p>Профессиональный подход к каждому заказу</p>
                        <p>Быть всегда на связи</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- SERVICES -->

<section class="services" id="services">
    <div class="container">
        <h2 class="services__title section-title">
            Услуги компании
        </h2>
    </div>
    <div class="services-carousel wow fadeInUp" data-wow-delay=".2s">
        <div class="services-carousel__wrap owl-carousel">

            <!-- по 3 элемента в одном item -->
        <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="services-carousel__item">
                <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="services-item">
                        <div class="services-item__img">
                            <img src="<?php echo e($item->photo); ?>" alt="service">
                        </div>
                        <div class="services-item__text">
                            <p><?php echo e($item->name_ru); ?></p>
                            <a href="#form">
                                <svg width="76" height="77" viewBox="0 0 76 77" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <ellipse cx="38" cy="38.5" rx="38" ry="38.5" fill="white"/>
                                    <path d="M48.2684 28.2292L27.5488 48.9488" stroke="#141DE0" stroke-width="2" stroke-miterlimit="10"/>
                                    <path d="M32.7287 27.7589H48.7393V43.7695" stroke="#141DE0" stroke-width="2" stroke-miterlimit="10"/>
                                </svg>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="services-carousel__arrows">
				<span class="arrow-left">
					<img src="img/arrow-left.svg" alt="ico">
				</span>
            <span class="arrow-right">
					<img src="img/arrow-right.svg" alt="ico">
				</span>
        </div>
    </div>
</section>

<!-- PROJECTS -->

<section class="projects" id="projects">
    <div class="container">
        <h2 class="projects__title section-title">
            Реализованные проекты
        </h2>
        <div class="projects-arrows">
            <span class="arrow-left">
                <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19 31L32 18" stroke="#141DE0" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M18.5 22V31" stroke="#141DE0" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M28 31.5H19" stroke="#141DE0" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </span>
            <span class="arrow-right">
                <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M31 19L18 32" stroke="#141DE0" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M31.5 28V19" stroke="#141DE0" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M22 18.5H31" stroke="#141DE0" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </span>
        </div>
    </div>
    <div class="projects-carousel owl-carousel wow fadeInLeft" data-wow-delay=".3s">
        <?php $__currentLoopData = $completed_projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $completed_project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="projects-carousel__item">
                <img src="<?php echo e($completed_project->photo); ?>" alt="project">
                <span></span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<!-- CHOOSE -->

<section class="choose">
    <div class="container">
        <h2 class="choose__title section-title">
            Нас выбирают
        </h2>
        <div class="choose-wrap">
            <div class="choose-col">
                <div class="choose-item wow fadeIn" data-wow-delay=".6s">
                    <div class="choose-item__inner">
                        <div class="choose-item__front">
                            <img src="img/choose/1.png" alt="Choose">
                        </div>
                        <div class="choose-item__back">
                            <img src="img/choose/1-1.png" alt="Choose">
                        </div>
                    </div>
                </div>
            </div>
            <div class="choose-col">
                <div class="choose-item wow fadeIn" data-wow-delay=".6s">
                    <div class="choose-item__inner">
                        <div class="choose-item__front">
                            <img src="img/choose/2.png" alt="Choose">
                        </div>
                        <div class="choose-item__back">
                            <img src="img/choose/2-1.png" alt="Choose">
                        </div>
                    </div>
                </div>
                <div class="choose-item wow fadeIn" data-wow-delay=".8s">
                    <div class="choose-item__inner">
                        <div class="choose-item__front">
                            <img src="img/choose/3.png" alt="Choose">
                        </div>
                        <div class="choose-item__back">
                            <img src="img/choose/3-1.png" alt="Choose">
                        </div>
                    </div>
                </div>
            </div>
            <div class="choose-col">
                <div class="choose-item wow fadeIn" data-wow-delay=".3s">
                    <div class="choose-item__inner">
                        <div class="choose-item__front">
                            <img src="img/choose/4.png" alt="Choose">
                        </div>
                        <div class="choose-item__back">
                            <img src="img/choose/4-1.png" alt="Choose">
                        </div>
                    </div>
                </div>
                <div class="choose-item wow fadeIn" data-wow-delay="1s">
                    <div class="choose-item__inner">
                        <div class="choose-item__front">
                            <img src="img/choose/5.png" alt="Choose">
                        </div>
                        <div class="choose-item__back">
                            <img src="img/choose/5-1.png" alt="Choose">
                        </div>
                    </div>
                </div>
                <div class="choose-item wow fadeIn" data-wow-delay=".4s">
                    <div class="choose-item__inner">
                        <div class="choose-item__front">
                            <img src="img/choose/6.png" alt="Choose">
                        </div>
                        <div class="choose-item__back">
                            <img src="img/choose/6-1.png" alt="Choose">
                        </div>
                    </div>
                </div>
            </div>
            <div class="choose-col">
                <div class="choose-item wow fadeIn" data-wow-delay=".7s">
                    <div class="choose-item__inner">
                        <div class="choose-item__front">
                            <img src="img/choose/7.png" alt="Choose">
                        </div>
                        <div class="choose-item__back">
                            <img src="img/choose/7-1.png" alt="Choose">
                        </div>
                    </div>
                </div>
                <div class="choose-item wow fadeIn" data-wow-delay=".9s">
                    <div class="choose-item__inner">
                        <div class="choose-item__front">
                            <img src="img/choose/8.png" alt="Choose">
                        </div>
                        <div class="choose-item__back">
                            <img src="img/choose/8-1.png" alt="Choose">
                        </div>
                    </div>
                </div>
                <div class="choose-item wow fadeIn" data-wow-delay=".9s">
                    <div class="choose-item__inner">
                        <div class="choose-item__front">
                            <img src="img/choose/9.png" alt="Choose">
                        </div>
                        <div class="choose-item__back">
                            <img src="img/choose/9-1.png" alt="Choose">
                        </div>
                    </div>
                </div>
            </div>
            <div class="choose-col">
                <div class="choose-item wow  fadeIn" data-wow-delay=".7s">
                    <div class="choose-item__inner">
                        <div class="choose-item__front">
                            <img src="img/choose/10.png" alt="Choose">
                        </div>
                        <div class="choose-item__back">
                            <img src="img/choose/10-1.png" alt="Choose">
                        </div>
                    </div>
                </div>
                <div class="choose-item wow  fadeIn" data-wow-delay=".9s">
                    <div class="choose-item__inner">
                        <div class="choose-item__front">
                            <img src="img/choose/11.png" alt="Choose">
                        </div>
                        <div class="choose-item__back">
                            <img src="img/choose/11-1.png" alt="Choose">
                        </div>
                    </div>
                </div>
            </div>
            <div class="choose-col">
                <div class="choose-item wow  fadeIn" data-wow-delay=".5s">
                    <div class="choose-item__inner">
                        <div class="choose-item__front">
                            <img src="img/choose/12.png" alt="Choose">
                        </div>
                        <div class="choose-item__back">
                            <img src="img/choose/5.png" alt="Choose">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- WHY -->

<section class="why">
    <div class="container">
        <h2 class="why__title section-title">
            Почему мы?
        </h2>
        <div class="why-wrap">
            <div class="why-item wow fadeInUp" data-wow-delay=".2s">
                <div class="why-item__ico">
                    <img src="img/why1.svg" alt="ico">
                </div>
                <h4 class="why-item__name">
                    Выдерживаем сроки
                </h4>
            </div>
            <div class="why-item wow fadeInUp" data-wow-delay=".3s">
                <div class="why-item__ico">
                    <img src="img/why2.svg" alt="ico">
                </div>
                <h4 class="why-item__name">
                    Гибкий подход к каждому клиенту
                </h4>
            </div>
            <div class="why-item wow fadeInUp" data-wow-delay=".4s">
                <div class="why-item__ico">
                    <img src="img/why3.svg" alt="ico">
                </div>
                <h4 class="why-item__name">
                    Многолетний опыт
                </h4>
            </div>
            <div class="why-item wow fadeInUp" data-wow-delay=".5s">
                <div class="why-item__ico">
                    <img src="img/why4.svg" alt="ico">
                </div>
                <h4 class="why-item__name">
                    Команда профессионалов
                </h4>
            </div>
            <div class="why-item wow fadeInUp" data-wow-delay=".6s">
                <div class="why-item__ico">
                    <img src="img/why5.svg" alt="ico">
                </div>
                <h4 class="why-item__name">
                    Собственное производство
                </h4>
            </div>
        </div>
    </div>
</section>

<!-- CONSULT -->

<section class="consult" id="form">
    <div class="container">
        <div class="consult-wrap">
            <h2 class="consult__title section-title">
                Получить бесплатную консультацию
            </h2>
        </div>
        <div class="consult__text">
            Заполните заявочную форму - персональный менеджер свяжется с вами и ответит на все вопросы
        </div>
        <div class="consult-form wow fadeInLeft" data-wow-delay=".2s">
            <input type="hidden" value="<?php echo e(csrf_token()); ?>" id="token">
            <input type="text" placeholder="Ваше имя" id="name">
            <input type="tel" class="form__tel" placeholder="Ваш телефон" id="phone">
            <button type="submit" onclick="send()">Оставить заявку</button>
        </div>
    </div>

    <!-- ПОКАЗАТЬ ЭТОТ БЛОК ПРИ ОТПРАВКЕ $('.consult-done').fadeIn(600)-->

    <div class="consult-done" id="done">
        <div class="consult-done__wrap">
            <div class="consult-done__title">
                Заявка отправлена!
            </div>
            <div class="consult-done__text">
                Cпасибо за проявленный интерес, в скором времени мы свяжемся с вами!
            </div>
            <div class="consult-done__img">
                <img src="img/done.svg" alt="ico">
            </div>
        </div>
    </div>
</section>

<!-- FOOTER -->

<footer class="footer" id="footer">
    <div class="footer-info">
        <div class="footer-info__item wow fadeInLeft" data-wow-delay=".4s">
            <div class="footer-info__title">
                Связаться с нами
            </div>
            <div class="footer-info__text footer-info__links">
                <a href="tel:+998999107770">+998 99 910 77 70</a>
                <a href="tel:+998788887771">+998 78 888 77 71</a>
                <a href="tel:+998981173334">+998 98 117 33 34</a>
                <a href="mailto:info@focusads.uz">info@focusads.uz</a>
            </div>
            <ul class="footer-info__social">
                <li>
                    <a href="#" target="_blank">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M20.9487 5.39287L18.2324 18.3764C18.0275 19.2928 17.493 19.5208 16.7336 19.0891L12.5948 15.998L10.5978 17.9447C10.3768 18.1687 10.1919 18.3561 9.76602 18.3561L10.0634 14.0839L17.7341 7.05857C18.0677 6.7572 17.6618 6.59022 17.2158 6.89159L7.7328 12.9435L3.65029 11.6484C2.76227 11.3674 2.7462 10.7484 3.83513 10.3167L19.8035 4.08148C20.5429 3.80047 21.1898 4.24845 20.9487 5.39287Z" fill="#fff"/>
                        </svg>
                    </a>
                </li>
                <li>
                    <a href="#" target="_blank">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M11.9978 9.3321C10.5289 9.3321 9.3301 10.5309 9.3301 11.9999C9.3301 13.4688 10.5289 14.6676 11.9978 14.6676C13.4668 14.6676 14.6656 13.4688 14.6656 11.9999C14.6656 10.5309 13.4668 9.3321 11.9978 9.3321ZM19.9991 11.9999C19.9991 10.8951 20.0091 9.80041 19.9471 8.69768C19.885 7.41684 19.5928 6.28009 18.6562 5.34348C17.7176 4.40486 16.5829 4.11467 15.302 4.05263C14.1973 3.99059 13.1026 4.0006 11.9999 4.0006C10.8951 4.0006 9.80041 3.99059 8.69768 4.05263C7.41684 4.11467 6.28009 4.40686 5.34348 5.34348C4.40486 6.28209 4.11467 7.41684 4.05263 8.69768C3.99059 9.80241 4.0006 10.8971 4.0006 11.9999C4.0006 13.1026 3.99059 14.1993 4.05263 15.302C4.11467 16.5829 4.40686 17.7196 5.34348 18.6562C6.28209 19.5948 7.41684 19.885 8.69768 19.9471C9.80241 20.0091 10.8971 19.9991 11.9999 19.9991C13.1046 19.9991 14.1993 20.0091 15.302 19.9471C16.5829 19.885 17.7196 19.5928 18.6562 18.6562C19.5948 17.7176 19.885 16.5829 19.9471 15.302C20.0111 14.1993 19.9991 13.1046 19.9991 11.9999ZM11.9978 16.1045C9.72636 16.1045 7.89315 14.2713 7.89315 11.9999C7.89315 9.72836 9.72636 7.89515 11.9978 7.89515C14.2693 7.89515 16.1025 9.72836 16.1025 11.9999C16.1025 14.2713 14.2693 16.1045 11.9978 16.1045ZM16.2707 8.68567C15.7403 8.68567 15.312 8.25739 15.312 7.72704C15.312 7.1967 15.7403 6.76841 16.2707 6.76841C16.801 6.76841 17.2293 7.1967 17.2293 7.72704C17.2294 7.85298 17.2048 7.9777 17.1566 8.09408C17.1085 8.21046 17.0379 8.3162 16.9489 8.40525C16.8598 8.4943 16.7541 8.5649 16.6377 8.61302C16.5213 8.66114 16.3966 8.68583 16.2707 8.68567Z" fill="white"/>
                        </svg>
                    </a>
                </li>
                <li>
                    <a href="#" target="_blank">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M13.392 20V12.7135H15.8501L16.2155 9.86063H13.392V8.04345C13.392 7.22021 13.6213 6.65657 14.8028 6.65657H16.3V4.11306C15.5715 4.03499 14.8393 3.9973 14.1067 4.00015C11.934 4.00015 10.4422 5.32658 10.4422 7.76163V9.85529H8V12.7082H10.4475V20H13.392Z" fill="white"/>
                        </svg>
                    </a>
                </li>
            </ul>
        </div>
        <div class="footer-info__item wow fadeInLeft" data-wow-delay=".3s">
            <div class="footer-info__title">
                Наш адрес
            </div>
            <div class="footer-info__text">
                г. Ташкент, Яшнабадский район, 1 проезд ул. Ош, 38.
            </div>
        </div>
        <div class="footer-info__item wow fadeInLeft" data-wow-delay=".2s">
            <div class="footer-info__title">
                График работы
            </div>
            <div class="footer-info__text">
                Пн-Сб: 09:00 - 18:00<br>
                Вс: выходной
            </div>
        </div>
    </div>
    <div class="footer-map">
        <div id="map"></div>
    </div>
    <div class="footer-copy">
        <p>
            Copyright  2023: FOCUS ADVIRTISING
        </p>
        <p>
            All rights reserved.
        </p>
        <a href="#" class="footer-top">
            <svg width="71" height="71" viewBox="0 0 71 71" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="36" cy="35" r="35" fill="#FFED00"/>
                <path d="M35.3553 26.8701L35.3553 45.2549" stroke="#141DE0" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M42.0728 32.8804L35.7089 26.5164" stroke="#141DE0" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M28.6378 32.8805L35.0018 26.5166" stroke="#141DE0" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </a>
    </div>
</footer>

<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/intlTelInput-jquery.min.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="https://api-maps.yandex.ru/2.1/?lang=ru_RU" type="text/javascript"></script>
<script src="js/map.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/three.min.js"></script>
<script src="js/vanta.fog.min.js"></script>
<script src="js/main.js"></script>
<script>
    function send(){
        let name = $('#name').val();
        let phone = $('#phone').val();
        let token = $('#token').val();

        if (name != '') {
            if (phone != '') {
                $.ajax({
                    type: "get",
                    url: "/send",
                    data: {
                        name: name,
                        phone: phone,
                    },
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    failure: function (errMsg) {
                    }
                });
                $("#name").val('');
                $("#phone").val('');
                setTimeout(() => {
                    $('#done').show();
                }, 500)
                setTimeout(() => {
                    $('#done').hide();
                }, 2000)
            }
            else {
                document.getElementById("phone").placeholder = "Введите номер телефона";
            }
        } else {
            document.getElementById("name").placeholder = "Введите ваше имя";
        }
    }
</script>
</body>
</html><?php /**PATH D:\wamp64\www\FocusAds\resources\views/welcome.blade.php ENDPATH**/ ?>