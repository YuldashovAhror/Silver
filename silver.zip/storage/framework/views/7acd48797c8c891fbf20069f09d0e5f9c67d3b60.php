<!doctype html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="index, follow">
    <title></title>
    <meta name="description" content="">
    <meta name="keywords" content=""/>
    <meta name="author" content="Novas"/>
    <meta name="google-site-verification" content=""/>
    <!--=======css Links======-->
    <!--    <link rel="manifest" href="img/favicon/site.webmanifest">-->
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('/img/favicon.svg')); ?>">

    <link rel="stylesheet" href="/css/normalize.css">
    <link rel="stylesheet" href="/css/fancybox.css">
    <link rel="stylesheet" href="/css/aos.css">
    <link rel="stylesheet" href="/css/main.css">
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body>




<?php echo $__env->make('components.front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('components.front.popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="https://unpkg.com/@lottiefiles/lottie-player@latest/dist/lottie-player.js"></script>
<script src="/js/jquery-3.6.0.min.js"></script>
<script src="/js/inputmask.min.js"></script>
<script src="/js/fancybox.umd.js"></script>
<script src="/js/aos.js"></script>
<script src="/js/main.js"></script>

<?php echo $__env->yieldContent('script'); ?>























</body>
</html>
<?php /**PATH C:\wamp64\www\silver\resources\views/layouts/front/main.blade.php ENDPATH**/ ?>