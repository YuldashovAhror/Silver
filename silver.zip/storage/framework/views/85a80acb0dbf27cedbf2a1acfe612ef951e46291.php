<div>
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header pb-0">
                    <h5>Добавить слово </h5>
                </div>
                    <div class="card-body">
                        <div class="row mt-3">
                            <div class="col-md-12">
                                <label class="col-form-label pt-0" for="exampleInputPassword1">Ключ</label>
                                <input class="form-control" id="exampleInputPassword1" type="text" placeholder="..." <?php if($edit == 0): ?> wire:model="key" <?php endif; ?>>
                                <?php if($edit == 0): ?> <?php $__errorArgs = ['key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error" style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-6">
                                <label class="col-form-label pt-0" for="exampleInputPassword1">Текст RU</label>
                                <input class="form-control" id="exampleInputPassword1" type="text" placeholder="..." wire:model="word_ru">
                            </div>
                            <div class="col-md-6">
                                <label class="col-form-label pt-0" for="exampleInputPassword1">Текст UZ</label>
                                <input class="form-control" id="exampleInputPassword1" type="text" placeholder="..." wire:model="word_uz">
                            </div>
                            
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-primary" type="button" wire:click="store()" >Сохранить</button>
                    </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h5>Все слова</h5>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Ключ</th>
                            <th scope="col">Текст RU</th>
                            <th scope="col">Текст UZ</th>
                            
                            <th scope="col">Действия </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php ($k=1); ?>
                        <?php $__currentLoopData = $words; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $word): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($k); ?></th>
                                <td>
                                    <?php if($edit != $word->id): ?>
                                        <?php echo e($word->key); ?>

                                    <?php else: ?>
                                        <input class="form-control" type="text" wire:model="key">
                                        <?php if($edit != 0): ?> <?php $__errorArgs = ['key'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error" style="color: red"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($edit != $word->id): ?>
                                        <?php echo e($word->word_ru); ?>

                                    <?php else: ?>
                                        <input class="form-control" type="text" wire:model="word_edit_ru">
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($edit != $word->id): ?>
                                        <?php echo e($word->word_uz); ?>

                                    <?php else: ?>
                                        <input class="form-control" type="text" wire:model="word_edit_uz">
                                    <?php endif; ?>
                                </td>
                                
                                <td>
                                    <?php if($edit != $word->id): ?>
                                        <button class="btn btn-success btn-xs" type="button" wire:click="edit(<?php echo e($word->id); ?>)">
                                            изменить
                                        </button>
                                    <?php else: ?>
                                        <button class="btn btn-warning btn-xs" type="button" wire:click="update(<?php echo e($word->id); ?>)">
                                            сохранить
                                        </button>
                                    <?php endif; ?>
                                    <button class="btn btn-danger btn-xs" type="button" wire:click="destroy(<?php echo e($word->id); ?>)">
                                        удалить
                                    </button>
                                </td>
                            </tr>
                            <?php ($k++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div> 
<?php /**PATH C:\wamp64\www\silver\resources\views/livewire/word.blade.php ENDPATH**/ ?>