<?php return array (
  'word' => 'App\\Http\\Livewire\\Word',
);